1. ber_awgn_comparison_minus5_35dB.png 文件是在awgn信道条件下snr范围从-5到3.5dB的，间隔为0.5，四个不同编码方式的信噪比对比
2. zoomed_in_awgn_ber.png 文件是上面文件在低snr的条件下的放大图像
3. ber_bsc.png 文件是在bsc信道条件下p概率范围从0.2到1间隔为0.05，四个不同编码方式的ber对比
4. zoomed_in_bsc_ber.png是ber_bsc.png在低翻转概率的放大版本
5. fer_bsc.png 文件是在bsc信道条件下p概率范围从0.2到1间隔为0.05，四个不同编码方式的fer对比
6. zoomed_in_bsc_fer.png文件是fer_bsc.png在低翻转概率的放大版本

